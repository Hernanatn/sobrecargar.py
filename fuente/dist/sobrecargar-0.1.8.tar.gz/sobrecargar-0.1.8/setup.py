from setuptools import setup, find_packages

setup(
    name='Medios_ARG',
    description="setuptools.build_meta",
    version='0.1.8',
    author           = 'Hernán A. Teszkiewicz Novick',
    author_email     = 'herni@cajadeideas.ar',
    license          =  'MIT'    ,
    url= 'https://github.com/Hernanatn/sobrecargar.py',
    download_url     =  'https://pypi.org/project/sobrecargar/0.1.8/#files',
    packages=['sobrecargar'],
)