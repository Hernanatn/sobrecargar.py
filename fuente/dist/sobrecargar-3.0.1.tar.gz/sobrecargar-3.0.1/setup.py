from setuptools import setup, find_packages

setup(
    name='sobrecargar',
    description="setuptools.build_meta",
    version='3.0.1',
    author           = 'Hernán A. Teszkiewicz Novick',
    author_email     = 'herni@cajadeideas.ar',
    url= 'https://github.com/Hernanatn/sobrecargar.py',
    download_url     =  'https://pypi.org/project/sobrecargar/0.2.0/#files',
    packages=['sobrecargar'],
)